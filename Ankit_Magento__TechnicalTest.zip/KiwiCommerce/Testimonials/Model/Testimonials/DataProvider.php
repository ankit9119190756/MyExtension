<?php
declare(strict_types=1);

namespace KiwiCommerce\Testimonials\Model\Testimonials;

use KiwiCommerce\Testimonials\Model\ResourceModel\Testimonials\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlInterface;

class DataProvider extends AbstractDataProvider
{
    protected $loadedData;
    protected $collection;
    protected $dataPersistor;
    protected $storeManager;
    protected $urlBuilder;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        UrlInterface $urlBuilder,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager = $storeManager;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $data = $model->getData();
            if (isset($data['profilepic']) && $data['profilepic']) {
                $data['profilepic'] = [
                    [
                        'name' => basename($data['profilepic']),
                        'url' => $this->getMediaUrl() ."testimonials/profile". $data['profilepic']
                    ]
                ];
            }
            $this->loadedData[$model->getId()] = $data;
        }

        $data = $this->dataPersistor->get('kiwicommerce_testimonials_testimonials');

        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('kiwicommerce_testimonials_testimonials');
        }

        return $this->loadedData;
    }

    private function getMediaUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }
}
