<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use Magento\Framework\Exception\LocalizedException;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\Controller\ResultInterface;

class Save extends \Magento\Backend\App\Action
{
    protected $dataPersistor;
    protected $uploaderFactory;
    protected $filesystem;

    /**
     * @param Context $context
     * @param DataPersistorInterface $dataPersistor
     * @param UploaderFactory $uploaderFactory
     * @param Filesystem $filesystem
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        UploaderFactory $uploaderFactory,
        Filesystem $filesystem
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->uploaderFactory = $uploaderFactory;
        $this->filesystem = $filesystem;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        
        if ($data) {
            $id = $this->getRequest()->getParam('testimonials_id');
            $model = $this->_objectManager->create(\KiwiCommerce\Testimonials\Model\Testimonials::class)->load($id);

            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Testimonials no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }

            // Handle image upload
            if (isset($_FILES['profilepic']) && isset($_FILES['profilepic']['name']) && $_FILES['profilepic']['name'] != '') {
                try {
                    $uploader = $this->uploaderFactory->create(['fileId' => 'profilepic']);
                    $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                    $uploader->setAllowRenameFiles(true);
                    $uploader->setFilesDispersion(true);

                    $mediaDirectory = $this->filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
                    $result = $uploader->save($mediaDirectory->getAbsolutePath('testimonials/profile'));

                    if ($result) {
                        $data = 'testimonials/profile' . $result['file'];
                    }
                } catch (\Exception $e) {
                    $this->messageManager->addErrorMessage($e->getMessage());
                }
            } elseif (isset($data['profilepic']['delete']) && $data['profilepic']['delete'] == '1') {
                $data['profilepic'] = '';
            } else {
                // Use existing image path if no new image is uploaded
                if (isset($data['profilepic']['value'])) {
                    $data['profilepic'] = $data['profilepic']['value'];
                }
            }
            // dd($data['profilepic'][0]['file']);

            $data['profilepic'] = $data['profilepic'][0]['file'];

            // dd($data);

            $model->setData($data);

            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the Testimonials.'));
                $this->dataPersistor->clear('kiwicommerce_testimonials_testimonials');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['testimonials_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Testimonials.'));
            }

            $this->dataPersistor->set('kiwicommerce_testimonials_testimonials', $data);
            return $resultRedirect->setPath('*/*/edit', ['testimonials_id' => $this->getRequest()->getParam('testimonials_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
